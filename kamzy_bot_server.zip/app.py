from flask import Flask, request, jsonify

app = Flask(__name__)

# Sample memory
robot_memory = {}

@app.route('/')
def home():
    return "Kamzy Bot is online!"

@app.route('/speak', methods=['POST'])
def speak():
    data = request.json
    message = data.get('message', '')
    return jsonify({"reply": f"Kamzy says: {message}"})

@app.route('/remember', methods=['POST'])
def remember():
    data = request.json
    key = data.get('key')
    value = data.get('value')
    robot_memory[key] = value
    return jsonify({"status": "Saved", "memory": robot_memory})

@app.route('/recall/<key>', methods=['GET'])
def recall(key):
    value = robot_memory.get(key, "Not found")
    return jsonify({"recall": value})

if __name__ == '__main__':
    app.run()
