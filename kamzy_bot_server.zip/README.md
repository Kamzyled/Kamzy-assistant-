# Kamzy Bot
This is a simple AI server for Kamzy’s ESP32-CAM robot project.
